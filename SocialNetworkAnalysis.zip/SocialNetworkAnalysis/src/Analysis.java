import java.io.*;
import java.util.*;

public class Analysis {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java Analysis <inputFile>");
            return;
        }

        String inputFile = args[0];
        List<Person> persons = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                Person person = new Person(parts[0]);
                for (int i = 1; i < parts.length; i++) {
                    person.follows.add(parts[i]);
                }
                persons.add(person);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Task 1: Calculate the density of the graph
        double density = calculateDensity(persons.size(), countEdges(persons));
        System.out.println("Density of the graph: " + density);

        // Task 2: Find the person with the highest number of followers
        Person mostFollowed = findMostFollowed(persons);
        System.out.println("Person with the highest number of followers: " + mostFollowed.name);

        // Task 3: Find the person who follows the highest number of people
        Person mostFollowing = findMostFollowing(persons);
        System.out.println("Person who follows the highest number of people: " + mostFollowing.name);

        // Task 4: Calculate the number of people at two degrees of separation from the first person
        int twoDegreesSeparation = calculateTwoDegreesSeparation(persons);
        System.out.println("Number of people at two degrees of separation: " + twoDegreesSeparation);

        // Task 5: Calculate the median value for the number of followers
        double medianFollowers = calculateMedianFollowers(persons);
        System.out.println("Median value for the number of followers: " + medianFollowers);

        // Task 6: Find the person to enroll for spreading information
        Person enrollPerson = findEnrollPerson(persons);
        System.out.println("Person to enroll for spreading information: " + enrollPerson.name);
    }

    // Define methods for each task

    // Task 1: Calculate the density of the graph
    private static double calculateDensity(int numVertices, int numEdges) {
        if (numVertices <= 1) {
            return 0.0; // Return 0 if there are no edges or only one vertex
        }
        return (double) numEdges / (numVertices * (numVertices - 1));
    }

    // Task 2: Find the person with the highest number of followers
    private static Person findMostFollowed(List<Person> persons) {
        Person mostFollowed = persons.get(0);
        for (Person person : persons) {
            if (person.followers.size() > mostFollowed.followers.size() ||
                    (person.followers.size() == mostFollowed.followers.size() &&
                            person.name.compareTo(mostFollowed.name) < 0)) {
                mostFollowed = person;
            }
        }
        return mostFollowed;
    }

    // Task 3: Find the person who follows the highest number of people
    private static Person findMostFollowing(List<Person> persons) {
        Person mostFollowing = persons.get(0);
        for (Person person : persons) {
            if (person.follows.size() > mostFollowing.follows.size() ||
                    (person.follows.size() == mostFollowing.follows.size() &&
                            person.name.compareTo(mostFollowing.name) < 0)) {
                mostFollowing = person;
            }
        }
        return mostFollowing;
    }

    // Task 4: Calculate the number of people at two degrees of separation from the first person
    private static int calculateTwoDegreesSeparation(List<Person> persons) {
        // Assuming the first person in the list is the starting person
        Set<String> followersAtTwoDegrees = new HashSet<>();
        Person startPerson = persons.get(0);
        for (String follower : startPerson.followers) {
            for (Person person : persons) {
                if (!person.name.equals(startPerson.name) &&
                        !person.followers.contains(follower) &&
                        person.follows.contains(follower)) {
                    followersAtTwoDegrees.add(person.name);
                }
            }
        }
        return followersAtTwoDegrees.size();
    }

    // Task 5: Calculate the median value for the number of followers
    private static double calculateMedianFollowers(List<Person> persons) {
        List<Integer> followersCounts = new ArrayList<>();
        for (Person person : persons) {
            followersCounts.add(person.followers.size());
        }
        Collections.sort(followersCounts);
        int size = followersCounts.size();
        if (size % 2 == 0) {
            int mid1 = followersCounts.get(size / 2 - 1);
            int mid2 = followersCounts.get(size / 2);
            return (mid1            + mid2) / 2.0;
        } else {
            return followersCounts.get(size / 2);
        }
    }

    // Task 6: Find the person to enroll for spreading information
    private static Person findEnrollPerson(List<Person> persons) {
        Person enrollPerson = null;
        int minFollowers = Integer.MAX_VALUE;
        for (Person person : persons) {
            int followersCount = person.followers.size();
            int followingCount = person.follows.size();
            if (followersCount < minFollowers ||
                    (followersCount == minFollowers && followingCount > enrollPerson.follows.size())) {
                enrollPerson = person;
                minFollowers = followersCount;
            }
        }
        return enrollPerson;
    }
}

class Person {
    String name;
    List<String> follows;
    List<String> followers;

    Person(String name) {
        this.name = name;
        this.follows = new ArrayList<>();
        this.followers = new ArrayList<>();
    }
}

